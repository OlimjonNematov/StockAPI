package project1;

public class weatherObj {
	main main;

	class main{
		double temp;
		double feels_like;
		double temp_min;
		double temp_max;
		int pressure;
		int humidity;
		int visibility;	
	}
}
