package project1;

public class stockObj {
	double price;
	double changes;
	String exchange;
}
